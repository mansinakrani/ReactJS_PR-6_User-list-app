export const ActionTypes = {
  LIST_USERS: "LIST_USERS",
};
