import { AppList } from "./components/AppList/AppList"

function App() {
  return (
    <>
      <AppList />
    </>
  );
}

export default App;